#include "animal.h"
#include "ajout_animaux.h"

Animal Animal_vide = {0,0,0,0,0,0,0,0,0,0,0,0};

int max(int a,int b)
{
    if(a>b)return a;
    else return b;
}
